#include "mbed.h"

// ==========================================
// 1. HARDWARE PIN DEFINITIONS & STARTUP CODE
// ==========================================

// Ultrasonic Sensor Pins
#define TRIG_PIN D8
#define ECHO_PIN D9

// Motor Driver Pins (Assuming L298N)
#define ENA_PIN D3  // PWM Pin for Motor A speed
#define ENB_PIN D5  // PWM Pin for Motor B speed
#define IN1_PIN D4  // Motor A direction
#define IN2_PIN D7  // Motor A direction
#define IN3_PIN D10 // Motor B direction
#define IN4_PIN D11 // Motor B direction

// Distance thresholds in centimeters
const float STOP_DISTANCE_MIN = 10.0; // Minimum suitable distance 
const float STOP_DISTANCE_MAX = 20.0; // Maximum suitable distance
const float MAX_FOLLOW_DIST = 80.0;   // Ignore objects beyond this range

// Global hardware object instantiations
DigitalOut trig(TRIG_PIN);
InterruptIn echo(ECHO_PIN);

PwmOut speedLeft(ENA_PIN);
PwmOut speedRight(ENB_PIN);
DigitalOut in1(IN1_PIN);
DigitalOut in2(IN2_PIN);
DigitalOut in3(IN3_PIN);
DigitalOut in4(IN4_PIN);

Timer echoTimer;
volatile float distance_cm = 0.0;
volatile bool distanceUpdated = false;

// ==========================================
// 2. INTERRUPT SERVICE ROUTINES (ISRs)
// ==========================================
// These ISRs handle the timing of the echo pulse without blocking the main CPU.

// ISR: Triggered when the Echo pin goes HIGH
void echo_rise_ISR() {
    echoTimer.reset();
    echoTimer.start();
}

// ISR: Triggered when the Echo pin goes LOW
void echo_fall_ISR() {
    echoTimer.stop();
    // Speed of sound is approx 343 m/s or 0.0343 cm/us.
    // Distance = (Time * Speed) / 2 (divide by 2 for round trip)
    distance_cm = echoTimer.elapsed_time().count() * 0.0343 / 2.0;
    distanceUpdated = true;
}

// ==========================================
// 3. MODULAR HELPER FUNCTIONS
// ==========================================

// Function to trigger the ultrasonic sensor [cite: 7]
void trigger_ultrasonic() {
    trig = 1;
    wait_us(10); // Standard 10 microsecond pulse required by HC-SR04
    trig = 0;
}

// Function to control the robot car's movement 
void set_motors(float speed, int direction) {
    // direction: 1 = Forward, -1 = Backward, 0 = Stop
    
    speedLeft.write(speed);
    speedRight.write(speed*2.7/4.0);
    
    if (direction == 1) {
        // Move Forward
        in1 = 1; in2 = 0;
        in3 = 0; in4 = 1;
    } 
    else if (direction == -1) {
        // Move Backward
        in1 = 0; in2 = 1;
        in3 = 1; in4 = 0;
    } 
    else {
        // Stop
        in1 = 0; in2 = 0;
        in3 = 0; in4 = 0;
        speedLeft.write(0.0f);
        speedRight.write(0.0f);
    }
}

// ==========================================
// 4. MAIN LOOP
// ==========================================
int main() {
    // Initialization code
    trig = 0;
    speedLeft.period(0.02f);  // Set PWM period for motors to 20ms (50Hz)
    speedRight.period(0.02f);
    set_motors(0.0, 0);       // Ensure car is stopped on startup
    
    // Attach the ISRs to the echo pin edges 
    echo.rise(&echo_rise_ISR);
    echo.fall(&echo_fall_ISR);
    
    printf("Ain Shams Mechatronics - Robot Car Follower Started\n");

    while (true) {
        // 1. Fire the ultrasonic trigger
        trigger_ultrasonic();
        
        // 2. Wait for the ping to return and for physical safety delays
        ThisThread::sleep_for(60ms); 
        
        // 3. Process the measured distance and control the robot [cite: 8, 9]
        if (distanceUpdated) {
            distanceUpdated = false;
            
            // Print distance to serial monitor for debugging
            printf("Distance: %d cm\n", (int)distance_cm);
            
            if (distance_cm < STOP_DISTANCE_MIN) {
                // Obstacle is too close, stop safely (or reverse slightly) 
                set_motors(0.0f, 0); 
            } 
            else if (distance_cm >= STOP_DISTANCE_MIN && distance_cm <= STOP_DISTANCE_MAX) {
                // Object has stopped at a suitable distance, stop safely 
                set_motors(0.0f, 0);
            } 
            else if (distance_cm > STOP_DISTANCE_MAX && distance_cm < MAX_FOLLOW_DIST) {
                // Object is moving away, follow it in a straight line 
                // 60% duty cycle (adjust based on your battery and motor specs)
                set_motors(0.20f, 1); 
            } 
            else {
                // Object is lost or out of bounds, stop the car
                set_motors(0.0f, 0);
            }
        }
    }
}